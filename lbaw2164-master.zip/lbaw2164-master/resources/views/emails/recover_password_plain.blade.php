



Forgot your password? 
Reset it using the token below. Just copy it and then enter it on the token field below the form where you requested the password reset.
If this password reset was not done by you don't worry, just ignore this email.

Token: {{$token}}

