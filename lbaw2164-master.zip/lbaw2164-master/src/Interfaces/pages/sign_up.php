<?php
    include_once("../templates/template_header.php");
    include_once("../templates/template_sign_up.php");
    include_once("../templates/template_footer.php");

    getHeader("ERASMUPS - Sign Up", "sign_up");
    getSignUp();
    getFooter();
?>