<?php
    header("Location: ./Interfaces/pages/about_us.php");
?>
