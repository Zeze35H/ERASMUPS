# ERASMUPS

- Docker Command: 
```
docker run -it -p 8000:80 -e DB_DATABASE="lbaw2164" -e DB_USERNAME"lbaw2164" -e DB_PASSWORD="XK580840" lbaw2164/lbaw2164
```

- App URL: http://lbaw2164.lbaw-prod.fe.up.pt/

- Group Elements:  
    - Diogo Santos - up201806878
    - José Eduardo Henriques - up201806372
    - Maria Marta Andrade - up201604530
    - Miguel Carreira Neves - up201608657