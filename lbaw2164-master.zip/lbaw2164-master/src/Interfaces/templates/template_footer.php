<?php
    function getFooter() { ?>
            <footer class="main-footer"> &copy; ERASMUPS 2021 </footer>
        </body>
    </html>
    <?php }
?>