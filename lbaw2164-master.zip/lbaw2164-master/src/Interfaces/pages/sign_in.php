<?php
    include_once("../templates/template_header.php");
    include_once("../templates/template_sign_in.php");
    include_once("../templates/template_footer.php");

    getHeader("ERASMUPS - Log In", "sign_in");
    getSignIn();
    getFooter();
?>
